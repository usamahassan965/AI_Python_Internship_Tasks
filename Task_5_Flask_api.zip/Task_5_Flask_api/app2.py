import torch
import torchvision.transforms as transforms
from PIL import Image
from flask import Flask, flash, request, redirect, url_for, render_template
import urllib.request
import os
from werkzeug.utils import secure_filename
# Load the PyTorch model
model = torch.load(r"C:\Users\HP\Desktop\Internship_Task\googleNet_Classifier,pt", map_location=torch.device('cpu'))
model.eval()

# Preprocess the input image
preprocess = transforms.Compose([
    transforms.Resize((220, 220)),
    transforms.ToTensor(),
    transforms.Normalize(
        (0.4124234616756439, 0.3674212694168091, 0.2578217089176178),
        (0.3268945515155792, 0.29282665252685547, 0.29053378105163574))
])

classes = ['daisy', 'dandelion', 'rose', 'sunflower', 'tulip']

 
app = Flask(__name__, template_folder='template', static_folder='static')
 
UPLOAD_FOLDER = 'static/uploads/'
 
app.secret_key = "secret key"
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
 
ALLOWED_EXTENSIONS = set(['png', 'jpg', 'jpeg', 'gif'])
 
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
     

@app.route('/')
def home():
    return render_template('test.html')
 
@app.route('/', methods=['POST'])
def upload_image():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        flash('No image selected for uploading')
        return redirect(request.url)
    if file and allowed_file(file.filename):
        # Preprocess the image
       
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        #print('upload_image filename: ' + filename)
        flash('Image successfully uploaded and displayed below')
        image = Image.open(file) 
        input_tensor = preprocess(image)
        input_batch = input_tensor.unsqueeze(0)

        # Make a prediction
        with torch.no_grad():
            output = model(input_batch)
        _, predicted_idx = torch.max(output, 1)
        predicted_label = classes[predicted_idx.item()]
        print(predict_label)
        return render_template('test.html', filename=filename,predicted_label=predicted_label)
    else:
        flash('Allowed image types are - png, jpg, jpeg, gif')
        return redirect(request.url)
 
@app.route('/display/<filename>')
def display_image(filename):
    #print('display_image filename: ' + filename)
    return redirect(url_for('static', filename='uploads/' + filename), code=301)

@app.route('/display/<filename>')
def predict_label(filename):
    #print('display_image filename: ' + filename)
    return redirect(url_for('static', filename='uploads/' + filename), code=301)


if __name__ == "__main__":
    app.run(debug=True)